# UI Context — LegalLens

> Governs: theme, colors, typography, component conventions.
> Source: bootstrapped from `docs/implementation.md` v1.0.

## ⚠️ Known gap — flagged, not resolved

The source specification (`docs/implementation.md`) defines product scope,
architecture, data models, and API contracts in detail, but **does not
define a visual design system**: no color palette, type scale, spacing
scale, or dark/light mode requirement is specified anywhere in the source
document.

Per the project's workflow rule ("no assumption-driven scope," "conflict
resolution requires surfacing"), this gap is being surfaced explicitly
rather than filled with invented values. **Before any visual UI work
begins, this file needs one of:**

1. A design system supplied by the user/team (Figma tokens, brand
   guidelines, an existing style guide), transcribed into this file, or
2. An explicit decision to default to un-customized Tailwind defaults /
   shadcn-style neutral theme, recorded here as a deliberate choice.

Until one of those happens, treat any color/spacing/typography value used
in generated UI code as a placeholder, not a locked-in convention — do not
let it silently become the de facto design system through repetition.

## What the source spec *does* establish

### Stack

- **Framework:** Next.js 14+, App Router, React 18+, TypeScript.
- **Styling:** Tailwind CSS (utility-first — chosen specifically because
  the comparison/diff UI needs many small conditional styles for risk
  levels and diff highlighting).
- **Server state:** TanStack Query (the UI is dominated by server-owned
  async state: job status polling, chat history, comparison results).

### Primary views (`src/app/`)

- Upload
- Document detail (`document/[id]`)
- Compare
- Chat

### Known components (`src/components/`)

- `DiffView` — renders the clause-aligned comparison diff with materiality
  highlighting.
- `RiskBadge` — renders a clause's risk level (`low`/`medium`/`high`).
- `ClauseCard` — renders an extracted clause with its excerpt and risk
  rationale.
- `ChatPane` — renders the document Q&A chat interface.

### Known hooks (`src/hooks/`)

`useDocumentStatus`, `useChatSession`, `useComparison` — thin wrappers
around TanStack Query for the corresponding polling/session state.

### Non-negotiable UI behaviors (these are product/compliance requirements,
not design choices, and apply regardless of what visual system is chosen)

- **Persistent disclaimer.** Every simplification, clause-extraction,
  comparison, and chat response must render a "this is general
  information, not legal advice" disclaimer in the UI. It must be
  **persistent, not a dismissible one-time modal.**
- **Visible, clickable citations.** Every Q&A answer and every
  simplification must render its citations so the user can see which
  passage of the source document backs a given claim (per
  `architecture.md` §3, step 6–7).
- **No raw HTML from document content.** Any UI surface that echoes
  user-uploaded document text must render it as escaped plain text, never
  as raw HTML, to prevent stored XSS via a maliciously crafted document
  (see `code-standards.md`).
- **Risk levels and materiality ratings must be visually distinguishable**
  at a glance (`RiskBadge`, `DiffView`) — exact colors are part of the
  unresolved design-system gap above, but the three risk levels
  (`low`/`medium`/`high`) and four materiality levels
  (`none`/`minor`/`significant`/`critical`) must each be distinct, not
  just labeled in text.
