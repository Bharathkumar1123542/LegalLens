"""
FastAPI app instantiation and middleware registration.

Phase 0 scope only: app boots, CORS is configured, and GET /health returns
200. Route modules (api/v1/auth.py, documents.py, ...) are added starting
in Phase 1 — see context/ai-workflow-rules.md.
"""
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.core.logging import configure_logging

configure_logging()
logger = logging.getLogger("legallens.api")

settings = get_settings()

app = FastAPI(
    title="LegalLens API",
    version="0.1.0",
    description="GenAI-powered plain-language legal document assistant.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["system"])
async def health() -> dict:
    """Liveness/readiness check. Phase 0 exit criteria: this returns 200."""
    return {"status": "ok", "environment": settings.ENVIRONMENT}


# Versioned API routers are mounted here starting in Phase 1, e.g.:
# from app.api.v1 import auth, documents
# app.include_router(auth.router, prefix="/api/v1/auth", tags=["auth"])
# app.include_router(documents.router, prefix="/api/v1/documents", tags=["documents"])
