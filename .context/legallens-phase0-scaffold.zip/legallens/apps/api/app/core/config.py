"""
Application configuration.

Loaded through a single Pydantic BaseSettings class so a missing required
environment variable fails application startup immediately rather than
failing lazily on first use (context/architecture.md, Configuration &
Environment).
"""
from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    ENVIRONMENT: Literal["development", "staging", "production"] = "development"

    # Data layer
    DATABASE_URL: str
    REDIS_URL: str
    CELERY_BROKER_URL: str

    # Object storage
    S3_BUCKET: str = "legallens-documents"
    S3_ENDPOINT_URL: str | None = None
    S3_ACCESS_KEY_ID: str
    S3_SECRET_ACCESS_KEY: str

    # LLM / embeddings providers
    ANTHROPIC_API_KEY: str
    VOYAGE_API_KEY: str

    # Auth
    JWT_SECRET: str
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 15
    REFRESH_TOKEN_EXPIRE_DAYS: int = 14

    # Uploads
    MAX_UPLOAD_SIZE_MB: int = 20
    ALLOWED_MIME_TYPES: str = (
        "application/pdf,"
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document,"
        "text/plain"
    )

    # Networking / rate limiting
    CORS_ORIGINS: str = "http://localhost:3000"
    RATE_LIMIT_PER_MINUTE: int = 30

    # Observability
    SENTRY_DSN: str | None = None
    LOG_LEVEL: str = "INFO"

    @property
    def allowed_mime_types_list(self) -> list[str]:
        return [m.strip() for m in self.ALLOWED_MIME_TYPES.split(",") if m.strip()]

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
