import type { Metadata } from "next";
import "../styles/globals.css";

export const metadata: Metadata = {
  title: "LegalLens",
  description:
    "Understand, compare, and act on legal documents — plain-language, source-grounded, not legal advice.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
