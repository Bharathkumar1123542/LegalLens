import { headers } from "next/headers";

async function getApiHealth() {
  const base =
    process.env.NEXT_PUBLIC_API_BASE_URL?.replace(/\/api\/v1$/, "") ??
    "http://localhost:8000";
  try {
    const res = await fetch(`${base}/health`, { cache: "no-store" });
    if (!res.ok) return { status: "unreachable" };
    return res.json();
  } catch {
    return { status: "unreachable" };
  }
}

export default async function Home() {
  // headers() forces this to render dynamically so the health check reflects
  // the current state of the API rather than being baked in at build time.
  headers();
  const health = await getApiHealth();

  return (
    <main style={{ padding: "3rem", fontFamily: "system-ui, sans-serif" }}>
      <h1>LegalLens</h1>
      <p>Phase 0 scaffold — Next.js and FastAPI talking to each other.</p>
      <p>
        API health check:{" "}
        <strong>{health.status === "ok" ? "connected" : "unreachable"}</strong>
      </p>
      <p style={{ color: "#666", fontSize: "0.9rem" }}>
        This is general information, not legal advice. (Persistent disclaimer
        placement — see context/ui-context.md.)
      </p>
    </main>
  );
}
