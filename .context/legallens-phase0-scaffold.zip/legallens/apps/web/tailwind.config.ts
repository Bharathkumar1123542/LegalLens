// Tailwind defaults are used as a placeholder. No design tokens (color
// palette, type scale, spacing scale) are defined in the source
// specification — see context/ui-context.md for the flagged gap. Do not
// treat the defaults below as a locked-in design system.
import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};

export default config;
