# LegalLens

GenAI-powered web app that helps a non-lawyer understand, compare, and act
on legal documents they already have — without generating legal advice or
replacing a licensed attorney.

## Project memory

This repo is developed against a `/context/` directory that is the single
source of truth for scope, architecture, UI conventions, code standards,
workflow rules, and current progress. **Read it before making any
implementation decision:**

1. [`context/project-overview.md`](context/project-overview.md)
2. [`context/architecture.md`](context/architecture.md)
3. [`context/ui-context.md`](context/ui-context.md)
4. [`context/code-standards.md`](context/code-standards.md)
5. [`context/ai-workflow-rules.md`](context/ai-workflow-rules.md)
6. [`context/progress-tracker.md`](context/progress-tracker.md)

The original full specification this was bootstrapped from lives at
[`docs/implementation.md`](docs/implementation.md).

## Status

**Phase 0 — Scaffolding** (see `context/progress-tracker.md` for detail).
`docker compose up` and the `/health` check have not yet been verified in
a real Docker environment — do that first.

## Quickstart (local development)

```bash
cp .env.example .env
# fill in ANTHROPIC_API_KEY, VOYAGE_API_KEY, and a real JWT_SECRET

cd infra
docker compose up --build
```

- API: http://localhost:8000/health
- Web: http://localhost:3000
- MinIO console: http://localhost:9001 (`legallens` / `legallens123`)

## Repository layout

```
apps/web/    Next.js frontend
apps/api/    FastAPI backend
infra/       docker-compose.yml, k8s manifests (post-MVP)
context/     living project documentation — read this first
docs/        original master specification
```

## Contributing

Follow `context/ai-workflow-rules.md`: implement only what the current
phase in `context/progress-tracker.md` permits, and update the context
files in the same change that changes what they document.
